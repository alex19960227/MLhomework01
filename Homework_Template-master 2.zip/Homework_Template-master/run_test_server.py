from app import flask_app as app

if __name__ == "__main__":
    app.run()