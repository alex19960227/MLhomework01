from flask import Flask


flask_app = Flask("HOMEWORK_TEMPLATE")


from .views import *
