from app import flask_app as app
import json
from datetime import datetime
from flask import request
import numpy





@app.route("/heartbeat")
def heartbeat():
    return json.dumps(
        {
            "status": True,
            "service": "Homework_Template",
            "datetime": f"{datetime.now()}"
        }
    )


@app.route("/sum", methods=['POST'])
def sum():
    content = request.json
    x = content['x']
    y = content['y']
    sum = x+y
    return json.dumps(
        {"sum": sum}
    )


@app.route("/minimum", methods=['POST'])
def minimum():
    content = request.json
    data = content['values']
    minimum = min(data)
    return json.dumps(
         {"minimum":minimum }
     )

@app.route("/product", methods=['POST'])
def product():
    content = request.json
    data = content['values']
    product = 1
    if data:
        for i in data:
            product *= i
    else:
        product = 0
    return json.dumps(
         {"product":product }
     )


@app.before_first_request
def load_app():
    print("Loading App Before First Request")
